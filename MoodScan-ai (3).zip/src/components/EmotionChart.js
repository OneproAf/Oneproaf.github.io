import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import Chart from 'https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js';

// Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyDFuRRL3p5IMP24f5-7Uo59q1DMLvmrgtI",
  authDomain: "moodscan-ai.firebaseapp.com",
  projectId: "moodscan-ai",
  storageBucket: "moodscan-ai.appspot.com",
  messagingSenderId: "1011087813147",
  appId: "1:1011087813147:web:c743a8f9120276741de6be"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

export async function renderMoodChart(canvasId) {
  const moodsRef = collection(db, "moods");
  const snapshot = await getDocs(moodsRef);

  const moodCounts = {};
  snapshot.forEach(doc => {
    const mood = doc.data().mood;
    moodCounts[mood] = (moodCounts[mood] || 0) + 1;
  });

  const labels = Object.keys(moodCounts);
  const data = Object.values(moodCounts);

  new Chart(document.getElementById(canvasId), {
    type: 'bar',
    data: {
      labels: labels,
      datasets: [{
        label: 'Mood Frequency',
        data: data,
        backgroundColor: '#4f46e5'
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false }
      }
    }
  });
}