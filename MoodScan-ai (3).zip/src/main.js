let model;
const video = document.getElementById("webcam");
const resultBox = document.getElementById("resultBox");

async function setupCamera() {
  const stream = await navigator.mediaDevices.getUserMedia({ video: true });
  video.srcObject = stream;
  return new Promise(resolve => {
    video.onloadedmetadata = () => {
      resolve(video);
    };
  });
}

async function loadModel() {
  model = await blazeface.load();
  console.log("BlazeFace model loaded");
}

async function analyzeMood() {
  const returnTensors = false;
  const predictions = await model.estimateFaces(video, returnTensors);

  if (predictions.length > 0) {
    const mood = getRandomMood();
    const recommendation = await fetchChatGPTRecommendation(mood);

    resultBox.innerHTML = `
      <h2>Detected Mood: ${mood}</h2>
      <p><strong>Recommendation:</strong> ${recommendation}</p>
    `;
  } else {
    resultBox.innerHTML = "<p>No face detected. Please try again.</p>";
  }
}

function getRandomMood() {
  const moods = ["Happy", "Sad", "Angry", "Calm", "Stressed", "Excited"];
  return moods[Math.floor(Math.random() * moods.length)];
}

async function fetchChatGPTRecommendation(mood) {
  const res = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: "Bearer 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"
    },
    body: JSON.stringify({
      model: "gpt-3.5-turbo",
      messages: [
        { role: "system", content: "You are a helpful mental wellness assistant." },
        { role: "user", content: `I'm feeling ${mood}. What should I do?` }
      ]
    })
  });

  const data = await res.json();
  return data.choices?.[0]?.message?.content || "No response";
}

(async () => {
  await setupCamera();
  await loadModel();
})();