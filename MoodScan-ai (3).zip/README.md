# MoodScan AI (Web Version)

MoodScan AI is a modern web application that:
- 📷 Detects user's face via webcam
- 🧠 Estimates mood (simulated for now)
- 🤖 Provides recommendations using OpenAI ChatGPT
- 💾 Saves mood data to Firebase
- 📊 Displays mood history chart via Chart.js

## 🚀 Technologies Used
- TensorFlow.js + BlazeFace
- Firebase Firestore & Auth
- OpenAI GPT-3.5 API
- Chart.js
- Vanilla JS + HTML/CSS

## 🛠 Project Setup

```bash
npm install
npm start
```

Use with a local server like `lite-server`.

## 🔐 Setup Required
- Replace `OPENAI_API_KEY` in `main.js`
- Setup Firebase config in `firebase.js`

## 🖼 Preview
Coming soon...

---
Created with ❤️ by MoodScan Dev Team
