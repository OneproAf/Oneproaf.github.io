import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-app.js";
import { getFirestore, addDoc, collection } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-firestore.js";
import { getAuth, signInAnonymously } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyDFuRRL3p5IMP24f5-7Uo59q1DMLvmrgtI",
  authDomain: "moodscan-ai.firebaseapp.com",
  projectId: "moodscan-ai",
  storageBucket: "moodscan-ai.appspot.com",
  messagingSenderId: "1011087813147",
  appId: "1:1011087813147:web:c743a8f9120276741de6be",
  measurementId: "G-EHJB14ZBPG"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const auth = getAuth(app);

signInAnonymously(auth)
  .then(() => console.log("Signed in anonymously"))
  .catch((error) => console.error("Auth error", error));

export async function saveMood(mood, recommendation) {
  try {
    await addDoc(collection(db, "moods"), {
      mood,
      recommendation,
      timestamp: new Date()
    });
  } catch (e) {
    console.error("Error saving mood:", e);
  }
}