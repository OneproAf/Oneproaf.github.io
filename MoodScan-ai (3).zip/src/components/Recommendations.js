export function renderRecommendation(mood, recommendation) {
  const box = document.getElementById("resultBox");
  box.innerHTML = `
    <h2>Mood: ${mood}</h2>
    <p><strong>Suggestion:</strong> ${recommendation}</p>
  `;
}